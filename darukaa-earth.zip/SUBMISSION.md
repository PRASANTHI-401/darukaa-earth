# Darukaa.Earth - Hackathon Submission Deliverable

### 1. GitHub Repository Link
- **Repository URL**: `https://github.com/your-username/darukaa-earth`
- **Reviewer Access Granted to**:
  - `ankita.dasgupta@darukaa.com`
  - `harsh.kumar@darukaa.com`
  - `utkarsh.gauniyal@darukaa.com`
  - `guneet.mutreja@darukaa.com`

### 2. Live Demo URL
- **Live Deployment**: `https://darukaa-earth-demo.vercel.app` (or `https://darukaa-earth.onrender.com`)

### 3. Demo Credentials
- **Email**: `admin@darukaa.earth`
- **Password**: `Admin@Darukaa2024`
- **Role**: MRV Administrator (Full PostGIS Geometry Write & Project Creation Permissions)

### 4. Architecture & Key Features Summary
- **Backend**: Python FastAPI with JWT authentication, PostGIS spatial models via GeoAlchemy2 & Shapely geodesic polygon validation.
- **Frontend**: React 18, Mapbox GL JS / MapLibre GL for interactive polygon visualization and drawing tools, Highcharts & Chart.js for quarterly telemetry analytics.
- **Database**: PostgreSQL 15 + PostGIS 3.3.
- **Code Quality**: Husky + lint-staged pre-commit hooks, automated GitHub Actions CI pipeline running pytest and code linters.
